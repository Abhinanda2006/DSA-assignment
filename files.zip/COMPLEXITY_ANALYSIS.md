# Complexity Analysis

n = number of patients.

## Max Heap (priority queue)

| Operation | Time | Reason |
|---|---|---|
| Insert | O(log n) worst case; O(1) average for random data | Sift-up climbs at most the height, floor(log2 n) levels |
| Peek highest priority | **O(1)** | The maximum is always at the root, index 0 |
| Extract-max | O(log n) | Move last element to root, sift-down at most floor(log2 n) levels |
| Build heap from n items (bottom-up) | O(n) | Most nodes are near the leaves and sift very little |
| n insertions one by one | O(n log n) worst case | n x O(log n) |

- **Height:** the heap is a complete binary tree stored in an array, so height = floor(log2 n) for every input order. For n = 7 the height is 2.
- **Space:** O(n) to hold the n patients, with **O(1) auxiliary** space, since sift-up and sift-down are iterative.

## Heap Sort

| Case | Time |
|---|---|
| Best | O(n log n) |
| Average | O(n log n) |
| Worst | O(n log n) |

- Build heap costs O(n), followed by (n-1) extractions of O(log n) each, so the total is O(n log n).
- **Space:** O(1) auxiliary, since it sorts in place. It is not stable.

## Quick Sort

| Case | Time | When |
|---|---|---|
| Best | O(n log n) | Pivot always splits the array evenly |
| Average | O(n log n) | Random-like input |
| Worst | O(n^2) | Pivot is always the minimum or maximum (e.g. already sorted input with last-element pivot) |

- **Recursion depth:** O(log n) on average (2 for the given input), up to O(n) in the worst case.
- **Space:** O(log n) auxiliary stack on average, O(n) in the worst case. It sorts in place and is not stable.

## Cost of the hospital scenario (continuous arrivals, highest priority needed at once)

| Approach | Handling one new patient and finding the top patient | Handling n arrivals in a row |
|---|---|---|
| Max Heap | Insert O(log n) + peek O(1) | O(n log n) |
| Re-run Quick Sort after each arrival | O(n log n) average, O(n^2) worst | O(n^2 log n) average |
| Insert into an already sorted array | O(n) (shifting) | O(n^2) |
