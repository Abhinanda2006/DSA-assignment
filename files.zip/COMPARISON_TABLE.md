# Comparison Table

Input: `45 72 30 90 65 50 85` (n = 7). Observed values come from the program outputs in the `*_output.txt` files.

## Observed results (from execution)

| Metric | Max Heap (insertions only) | Heap Sort (full) | Quick Sort |
|---|---|---|---|
| Comparisons | 9 | 21 (build 8 + extract 13) | 12 |
| Swaps | 5 | 18 (build 4 + extract 14) | 6 |
| Structure height / depth | Heap height = 2 | Heap height = 2 | Recursion depth = 2 (4 partition calls) |
| Final result | Heap [90, 72, 85, 45, 65, 30, 50]; peek = 90 | [30, 45, 50, 65, 72, 85, 90] | [30, 45, 50, 65, 72, 85, 90] |

## Theoretical comparison

| Criterion | Max Heap / Heap Sort | Quick Sort |
|---|---|---|
| Structure and height | Complete binary tree in an array; always balanced; height floor(log2 n) | No persistent structure; recursion tree depth O(log n) average, O(n) worst |
| Time: get highest priority | O(1) (root) | O(1) only after a full sort |
| Time: add a new patient | O(log n) | Re-sort O(n log n) (or O(n) sorted insertion) |
| Time: sort all | O(n log n) in all cases | O(n log n) average, O(n^2) worst |
| Space | O(1) auxiliary | O(log n) average stack, O(n) worst |
| Stable | No | No |
| Suited to a live priority queue | **Yes** | No (a batch sorting tool) |
