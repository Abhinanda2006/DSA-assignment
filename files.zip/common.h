#ifndef COMMON_H
#define COMMON_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXN 100

/* Reads integers separated by whitespace from a file. Returns count, or -1 on error. */
static int read_input(const char *path, int *a) {
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "Cannot open input file: %s\n", path); return -1; }
    int n = 0;
    while (n < MAXN && fscanf(f, "%d", &a[n]) == 1) n++;
    fclose(f);
    return n;
}

/* Prints array as [a, b, c] into buf. */
static void arr_str(const int *a, int n, char *buf) {
    int p = sprintf(buf, "[");
    for (int i = 0; i < n; i++)
        p += sprintf(buf + p, "%s%d", i ? ", " : "", a[i]);
    sprintf(buf + p, "]");
}

static inline int floor_log2(int n) { int h = 0; while (n > 1) { n >>= 1; h++; } return h; }
#endif
