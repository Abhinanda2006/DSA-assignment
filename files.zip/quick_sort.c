/* Part (b2): Quick Sort (Lomuto partition, last element as pivot) with trace table. */
#include "common.h"

static long comps = 0, swaps = 0;
static int calls = 0, max_depth = 0, N;
static void swap_int(int *x, int *y) { int t = *x; *x = *y; *y = t; }

static void quick_sort(int *a, int lo, int hi, int depth) {
    if (lo >= hi) return;
    if (depth > max_depth) max_depth = depth;
    int pivot = a[hi], i = lo - 1;
    for (int j = lo; j < hi; j++) {
        comps++;
        if (a[j] <= pivot) {
            i++;
            if (i != j) { swap_int(&a[i], &a[j]); swaps++; }
        }
    }
    if (i + 1 != hi) { swap_int(&a[i + 1], &a[hi]); swaps++; }
    char s[512];
    arr_str(a, N, s);
    printf("| %d | %d | [%d..%d] | %d | %d | %s | %ld | %ld |\n",
           ++calls, depth, lo, hi, pivot, i + 1, s, comps, swaps);
    quick_sort(a, lo, i, depth + 1);
    quick_sort(a, i + 2, hi, depth + 1);
}

int main(int argc, char **argv) {
    int a[MAXN];
    char s[512];
    const char *path = argc > 1 ? argv[1] : "input.txt";
    N = read_input(path, a);
    if (N <= 0) return 1;

    arr_str(a, N, s);
    printf("PART (b2): QUICK SORT (Lomuto, last element as pivot)\nInput: %s\n\n", s);
    printf("Trace table\n");
    printf("| Call | Depth | Range | Pivot | Pivot final index | Array after partition | Cum. comparisons | Cum. swaps |\n");
    printf("|---|---|---|---|---|---|---|---|\n");
    quick_sort(a, 0, N - 1, 0);
    arr_str(a, N, s);
    printf("\nFinal sorted output (ascending): %s\n", s);
    int d[MAXN]; for (int i = 0; i < N; i++) d[i] = a[N - 1 - i];
    arr_str(d, N, s);
    printf("Priority order (descending):     %s\n", s);
    printf("TOTAL comparisons = %ld, TOTAL swaps = %ld, partition calls = %d, max recursion depth = %d\n",
           comps, swaps, calls, max_depth);
    return 0;
}
