# Final Conclusion

**The Max Heap (priority queue) is the most suitable approach** for a hospital that continuously admits patients and needs the highest-priority patient immediately.

Justification, from the execution results and the complexity analysis:

1. **The heap kept the most critical patient at the root at every step.** After each of the 7 insertions the trace table shows the highest score at index 0, ending with 90. The whole queue took only 9 comparisons and 5 swaps to build.
2. **Cheap updates.** Each new patient costs O(log n) (at most 2 levels for 7 patients), and reading the top patient is O(1). Quick Sort would have to re-sort on every arrival, at O(n log n) each time, or shift elements in a sorted array at O(n).
3. **Guaranteed performance.** Heap height is always floor(log2 n), so operations never degrade. Quick Sort's O(n^2) worst case (bad pivots) is unacceptable when delays affect critical patients.
4. **Lower memory.** The heap needs O(1) auxiliary space, while Quick Sort needs an O(log n) stack, or O(n) in the worst case.
5. **Different jobs.** Quick Sort finished with fewer comparisons and swaps on this small input (12/6 versus Heap Sort's 21/18), and it is a good choice for a one-off batch sort, such as a full sorted report. But sorting is not needed to serve the next patient. Serving needs only the maximum, which the heap provides directly, and it produces the same priority order (90, 85, 72, 65, 50, 45, 30) through repeated extract-max.
