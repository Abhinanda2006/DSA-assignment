/* Part (a): Max Heap for hospital patient severity scores (priority queue). */
#include "common.h"

static int heap[MAXN], size = 0;
static long comps = 0, swaps = 0;
static char path_buf[256];

static void swap_int(int *x, int *y) { int t = *x; *x = *y; *y = t; }

/* Insert with sift-up. Records the swaps performed in path_buf. */
static void insert(int v) {
    heap[size++] = v;
    int i = size - 1;
    path_buf[0] = '\0';
    while (i > 0) {
        int p = (i - 1) / 2;
        comps++;                       /* compare child with parent */
        if (heap[i] > heap[p]) {
            char t[40];
            sprintf(t, "%s%d<->%d", path_buf[0] ? ", " : "", heap[i], heap[p]);
            strcat(path_buf, t);
            swap_int(&heap[i], &heap[p]);
            swaps++;
            i = p;
        } else break;
    }
    if (!path_buf[0]) strcpy(path_buf, "none");
}

/* Remove and return the maximum (root) with sift-down. */
static int extract_max(void) {
    int top = heap[0];
    heap[0] = heap[--size];
    int i = 0;
    while (1) {
        int l = 2 * i + 1, r = 2 * i + 2, m = i;
        if (l < size) { comps++; if (heap[l] > heap[m]) m = l; }
        if (r < size) { comps++; if (heap[r] > heap[m]) m = r; }
        if (m == i) break;
        swap_int(&heap[i], &heap[m]);
        swaps++;
        i = m;
    }
    return top;
}

int main(int argc, char **argv) {
    int in[MAXN], buf_n;
    char s[512];
    const char *path = argc > 1 ? argv[1] : "input.txt";
    buf_n = read_input(path, in);
    if (buf_n <= 0) return 1;

    arr_str(in, buf_n, s);
    printf("PART (a): MAX HEAP INSERTION\nInput severity scores: %s\n\n", s);
    printf("Trace table: insertion (sift-up)\n");
    printf("| Step | Insert | Swaps performed (sift-up) | Comparisons | Swaps | Heap after insertion | Height |\n");
    printf("|---|---|---|---|---|---|---|\n");
    for (int k = 0; k < buf_n; k++) {
        long c0 = comps, s0 = swaps;
        insert(in[k]);
        arr_str(heap, size, s);
        printf("| %d | %d | %s | %ld | %ld | %s | %d |\n", k + 1, in[k], path_buf,
               comps - c0, swaps - s0, s, floor_log2(size));
    }
    printf("\nTotal for %d insertions: comparisons = %ld, swaps = %ld\n", buf_n, comps, swaps);

    printf("\nFinal heap (level by level):\n");
    int start = 0, lvl = 0;
    while (start < size) {
        int w = 1 << lvl, end = start + w < size ? start + w : size;
        arr_str(heap + start, end - start, s);
        printf("  Level %d: %s\n", lvl, s);
        start += w; lvl++;
    }
    printf("Heap size = %d, height = floor(log2 %d) = %d\n", size, size, floor_log2(size));
    printf("Highest-priority patient (peek, O(1)): %d\n", heap[0]);

    printf("\nTrace table: serving patients (extract-max)\n");
    printf("| Step | Patient served | Heap after removal |\n|---|---|---|\n");
    int step = 1, order[MAXN], cnt = 0;
    while (size > 0) {
        int t = extract_max();
        order[cnt++] = t;
        arr_str(heap, size, s);
        printf("| %d | %d | %s |\n", step++, t, size ? s : "[] (empty)");
    }
    arr_str(order, cnt, s);
    printf("\nServing order (highest priority first): %s\n", s);
    return 0;
}
