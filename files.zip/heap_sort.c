/* Part (b1): Heap Sort with trace table. */
#include "common.h"

static long comps = 0, swaps = 0;
static void swap_int(int *x, int *y) { int t = *x; *x = *y; *y = t; }

static void sift_down(int *a, int n, int i) {
    while (1) {
        int l = 2 * i + 1, r = 2 * i + 2, m = i;
        if (l < n) { comps++; if (a[l] > a[m]) m = l; }
        if (r < n) { comps++; if (a[r] > a[m]) m = r; }
        if (m == i) return;
        swap_int(&a[i], &a[m]);
        swaps++;
        i = m;
    }
}

int main(int argc, char **argv) {
    int a[MAXN], n;
    char s[512];
    const char *path = argc > 1 ? argv[1] : "input.txt";
    n = read_input(path, a);
    if (n <= 0) return 1;

    arr_str(a, n, s);
    printf("PART (b1): HEAP SORT\nInput: %s\n\n", s);
    printf("Trace table\n");
    printf("| Step | Phase | Action | Array | Cum. comparisons | Cum. swaps |\n|---|---|---|---|---|---|\n");
    int step = 1;
    for (int i = n / 2 - 1; i >= 0; i--) {
        sift_down(a, n, i);
        arr_str(a, n, s);
        printf("| %d | Build heap | Heapify subtree at index %d | %s | %ld | %ld |\n", step++, i, s, comps, swaps);
    }
    long bc = comps, bs = swaps;
    for (int end = n - 1; end > 0; end--) {
        int mx = a[0];
        swap_int(&a[0], &a[end]); swaps++;
        sift_down(a, end, 0);
        arr_str(a, n, s);
        printf("| %d | Extract | Move max %d to index %d, restore heap on [0..%d] | %s | %ld | %ld |\n",
               step++, mx, end, end - 1, s, comps, swaps);
    }
    printf("\nBuild-heap phase: comparisons = %ld, swaps = %ld\n", bc, bs);
    printf("Extraction phase: comparisons = %ld, swaps = %ld\n", comps - bc, swaps - bs);
    printf("Heap height during build = floor(log2 %d) = %d\n", n, floor_log2(n));
    arr_str(a, n, s);
    printf("\nFinal sorted output (ascending): %s\n", s);
    int d[MAXN]; for (int i = 0; i < n; i++) d[i] = a[n - 1 - i];
    arr_str(d, n, s);
    printf("Priority order (descending):     %s\n", s);
    printf("TOTAL comparisons = %ld, TOTAL swaps = %ld\n", comps, swaps);
    return 0;
}
