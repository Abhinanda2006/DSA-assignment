# Hospital Priority Queue: Max Heap, Heap Sort and Quick Sort (C)

A hospital manages patients by severity score (higher score = higher priority).
Input data: `45 72 30 90 65 50 85`

All files are in this single folder.

| File | Content |
|---|---|
| `max_heap.c` | Part (a): Max Heap insertion and extract-max |
| `heap_sort.c` | Part (b): Heap Sort |
| `quick_sort.c` | Part (b): Quick Sort |
| `common.h` | Shared helpers (input reading, printing) |
| `input.txt` | Input data |
| `max_heap_output.txt`, `heap_sort_output.txt`, `quick_sort_output.txt` | Recorded program output (includes trace tables) |
| `TRACE_TABLES.md` | Trace tables for all three programs |
| `COMPLEXITY_ANALYSIS.md` | Time and space complexity |
| `COMPARISON_TABLE.md` | Observed and theoretical comparison |
| `CONCLUSION.md` | Final conclusion |
| `Makefile` | Build and run |

## Build and run

```bash
make run        # compiles with gcc and writes the *_output.txt files
# or manually:
gcc -o max_heap max_heap.c && ./max_heap input.txt
gcc -o heap_sort heap_sort.c && ./heap_sort input.txt
gcc -o quick_sort quick_sort.c && ./quick_sort input.txt
```

## Results summary

| Metric | Max Heap (insertions) | Heap Sort | Quick Sort |
|---|---|---|---|
| Comparisons | 9 | 21 | 12 |
| Swaps | 5 | 18 | 6 |
| Height / depth | 2 | 2 | 2 |
| Final result | Heap [90, 72, 85, 45, 65, 30, 50] | [30, 45, 50, 65, 72, 85, 90] | [30, 45, 50, 65, 72, 85, 90] |

**Conclusion:** the Max Heap is the most suitable structure for continuous patient arrival. Insert is O(log n), the top patient is read in O(1), and there is no need to re-sort. See `CONCLUSION.md`.
