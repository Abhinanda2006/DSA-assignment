# Trace Tables

Input data (`input.txt`): `45 72 30 90 65 50 85`
All tables are produced by the C programs. Raw output is in the `*_output.txt` files.

## (a) Max Heap: insertion trace (sift-up)

| Step | Insert | Swaps performed (sift-up) | Comparisons | Swaps | Heap after insertion | Height |
|---|---|---|---|---|---|---|
| 1 | 45 | none | 0 | 0 | [45] | 0 |
| 2 | 72 | 72<->45 | 1 | 1 | [72, 45] | 1 |
| 3 | 30 | none | 1 | 0 | [72, 45, 30] | 1 |
| 4 | 90 | 90<->45, 90<->72 | 2 | 2 | [90, 72, 30, 45] | 2 |
| 5 | 65 | none | 1 | 0 | [90, 72, 30, 45, 65] | 2 |
| 6 | 50 | 50<->30 | 2 | 1 | [90, 72, 50, 45, 65, 30] | 2 |
| 7 | 85 | 85<->50 | 2 | 1 | [90, 72, 85, 45, 65, 30, 50] | 2 |

Total for 7 insertions: **9 comparisons, 5 swaps**.

Final heap:
```
        90
      /    \
    72      85
   /  \    /  \
  45  65  30  50
```
Size 7, height = floor(log2 7) = **2**. Highest-priority patient (peek, O(1)): **90**.

### Serving patients (extract-max)

| Step | Patient served | Heap after removal |
|---|---|---|
| 1 | 90 | [85, 72, 50, 45, 65, 30] |
| 2 | 85 | [72, 65, 50, 45, 30] |
| 3 | 72 | [65, 45, 50, 30] |
| 4 | 65 | [50, 45, 30] |
| 5 | 50 | [45, 30] |
| 6 | 45 | [30] |
| 7 | 30 | [] (empty) |

Serving order: 90, 85, 72, 65, 50, 45, 30.

## (b1) Heap Sort trace

| Step | Phase | Action | Array | Cum. comparisons | Cum. swaps |
|---|---|---|---|---|---|
| 1 | Build heap | Heapify subtree at index 2 | [45, 72, 85, 90, 65, 50, 30] | 2 | 1 |
| 2 | Build heap | Heapify subtree at index 1 | [45, 90, 85, 72, 65, 50, 30] | 4 | 2 |
| 3 | Build heap | Heapify subtree at index 0 | [90, 72, 85, 45, 65, 50, 30] | 8 | 4 |
| 4 | Extract | Move max 90 to index 6, restore heap on [0..5] | [85, 72, 50, 45, 65, 30, 90] | 11 | 7 |
| 5 | Extract | Move max 85 to index 5, restore heap on [0..4] | [72, 65, 50, 45, 30, 85, 90] | 15 | 10 |
| 6 | Extract | Move max 72 to index 4, restore heap on [0..3] | [65, 45, 50, 30, 72, 85, 90] | 18 | 13 |
| 7 | Extract | Move max 65 to index 3, restore heap on [0..2] | [50, 45, 30, 65, 72, 85, 90] | 20 | 15 |
| 8 | Extract | Move max 50 to index 2, restore heap on [0..1] | [45, 30, 50, 65, 72, 85, 90] | 21 | 17 |
| 9 | Extract | Move max 45 to index 1, restore heap on [0..0] | [30, 45, 50, 65, 72, 85, 90] | 21 | 18 |

- Build-heap phase: 8 comparisons, 4 swaps.
- Extraction phase: 13 comparisons, 14 swaps.
- Final sorted output: **[30, 45, 50, 65, 72, 85, 90]**; priority order (descending): [90, 85, 72, 65, 50, 45, 30].
- **Total: 21 comparisons, 18 swaps.**

## (b2) Quick Sort trace (Lomuto partition, last element as pivot)

| Call | Depth | Range | Pivot | Pivot final index | Array after partition | Cum. comparisons | Cum. swaps |
|---|---|---|---|---|---|---|---|
| 1 | 0 | [0..6] | 85 | 5 | [45, 72, 30, 65, 50, 85, 90] | 6 | 3 |
| 2 | 1 | [0..4] | 50 | 2 | [45, 30, 50, 65, 72, 85, 90] | 10 | 5 |
| 3 | 2 | [0..1] | 30 | 0 | [30, 45, 50, 65, 72, 85, 90] | 11 | 6 |
| 4 | 2 | [3..4] | 72 | 4 | [30, 45, 50, 65, 72, 85, 90] | 12 | 6 |

- Final sorted output: **[30, 45, 50, 65, 72, 85, 90]**; priority order (descending): [90, 85, 72, 65, 50, 45, 30].
- **Total: 12 comparisons, 6 swaps, 4 partition calls, maximum recursion depth 2.**
